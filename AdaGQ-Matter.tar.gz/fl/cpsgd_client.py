"""
cpSGD (Composed Private SGD) Baseline Client.

Implements the cpSGD method from:
  Kairouz et al., "The Composition Theorem for Differential Privacy,"
  and Kairouz, McMahan, et al., "Discrete Gaussian Mechanism for DP"

cpSGD uses the composed quantization mechanism:
  1. Gradient clipping (same as DP-FedAvg)
  2. Randomized rounding to discrete levels (quantization-based DP)
  3. Composition accounting using the discrete Gaussian / RDP

Key difference from DP-FedAvg: cpSGD uses quantization noise as the 
DP mechanism instead of additive Gaussian noise, providing tighter 
composition bounds under certain regimes.

Reference: Kairouz et al., "Discrete Gaussian for Differential Privacy" (NeurIPS 2021)
"""

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from typing import Dict, Optional
import math

from models.dnn import AnomalyDNN
from core.dp import RDPAccountant, adaptive_clip
from utils.metrics import compute_metrics


class BaselineCpSGDClient:
    """cpSGD client — discrete Gaussian mechanism for DP via quantization.

    Pipeline:
    1. Local training (standard SGD)
    2. Compute gradient (parameter difference)
    3. Clip gradient to norm C
    4. Quantize gradient to discrete levels (each coordinate → discrete Gaussian)
    5. Upload quantized gradient
    6. RDP accounting for composed discrete Gaussian

    The key insight: instead of adding continuous Gaussian noise after
    quantization (like DP-FedAvg), cpSGD uses the quantization itself
    as the privacy mechanism via the discrete Gaussian distribution.
    """

    def __init__(self, client_id, model, X_train, y_train, X_test, y_test, config,
                 epsilon=None, delta=None, clipping_norm=None, num_levels=4):
        from fl.baseline_client import FLClient
        self.client_id = client_id
        self.model = model
        self.X_train = X_train
        self.y_train = y_train
        self.X_test = X_test
        self.y_test = y_test
        self.config = config
        self.device = config.get("device", "cpu")
        self.eta = float(config.get("eta", 0.01))
        self.E_local = int(config.get("E_local", 5))
        self.batch_size = int(config.get("batch_size", 32))
        self.model = self.model.to(self.device)

        self.epsilon = float(epsilon if epsilon is not None else config.get("epsilon", 3.0))
        self.delta = float(delta if delta is not None else config.get("delta", 1e-5))
        self.clipping_norm = float(clipping_norm if clipping_norm is not None
                                   else config.get("dp_clipping_norm", 1.0))
        self.n_clients = int(config.get("N", 10))
        self.num_levels = int(num_levels)  # Number of quantization levels (like b in AdaGQ)

        # RDP accountant
        self.accountant = RDPAccountant(
            epsilon_target=self.epsilon,
            delta_target=self.delta,
            sigma=1.0,
            kappa_default=1.0,
        )

        # ★ Matched-σ support for fair comparison
        self.fixed_sigma = float(config.get("dp_fixed_sigma", 0.0)) if config.get("dp_fixed_sigma") else None

    def get_parameters(self, config=None):
        return [val.detach().cpu().numpy() for val in self.model.state_dict().values()]

    def set_parameters(self, parameters):
        params_dict = zip(self.model.state_dict().keys(), parameters)
        state_dict = {k: torch.tensor(v, device=self.device) for k, v in params_dict}
        self.model.load_state_dict(state_dict, strict=True)

    def fit(self, parameters, config):
        round_idx = config.get("current_round", 0) if config else 0
        total_rounds = config.get("total_rounds", 50) if config else 50

        self.set_parameters(parameters)
        global_flat = self.model.get_parameters_flat().detach().cpu().numpy()
        self._local_train()
        local_flat = self.model.get_parameters_flat().detach().cpu().numpy()

        # Compute gradient
        gradient = local_flat - global_flat
        d = len(gradient)

        # Step 1: Clip gradient to norm C
        clipped_gradient, grad_norm = adaptive_clip(gradient, self.clipping_norm)

        # Step 2: cpSGD quantization + discrete Gaussian noise
        # Compute σ for this round (same adaptive mechanism as DP-FedAvg)
        if self.fixed_sigma is not None and self.fixed_sigma > 0:
            sigma = self.fixed_sigma
        else:
            sigma = self.accountant.compute_adaptive_noise(
                round_idx, total_rounds, kappa=1.0, n_clients=self.n_clients
            )

        # cpSGD core: quantize each coordinate + add discrete Gaussian noise
        quantized_noisy = self._cpSGD_mechanism(clipped_gradient, sigma, d)

        # Step 3: Accumulate RDP
        epsilon_used = self.accountant.accumulate_round(
            sigma, kappa=1.0, n_clients=self.n_clients, shuffling=False
        )

        # Reconstruct parameters
        updated_flat = global_flat + quantized_noisy

        # Split back to per-layer arrays
        return_params = []
        offset = 0
        for p in self.model.parameters():
            numel = p.numel()
            param_flat = updated_flat[offset:offset + numel].astype(np.float32)
            return_params.append(param_flat.reshape(p.shape))
            offset += numel

        # Communication: quantized + index overhead
        # cpSGD uses num_levels bits per coordinate + small overhead
        bits_per_coord = max(1, int(math.ceil(math.log2(self.num_levels))))
        comm_bytes = d * bits_per_coord // 8 + 4  # +4 for metadata

        metrics = {
            "method": "cpsgd",
            "comm_bytes": comm_bytes,
            "epsilon_current": epsilon_used,
            "sigma": sigma,
            "grad_norm": grad_norm,
        }
        return return_params, len(self.X_train), metrics

    def _cpSGD_mechanism(self, gradient, sigma, d):
        """cpSGD: quantize + discrete Gaussian noise per coordinate.

        For each coordinate g_j:
        1. Scale to [-1, 1]: g_j / C (already clipped)
        2. Round to nearest quantization level
        3. Add discrete Gaussian noise with scale σ/sqrt(d)

        The discrete Gaussian provides DP guarantees that compose
        more tightly than the continuous Gaussian under many compositions.
        """
        C = self.clipping_norm
        L = self.num_levels  # quantization levels

        # Normalize to [-1, 1]
        if C > 0:
            normalized = np.clip(gradient / C, -1.0, 1.0)
        else:
            normalized = gradient

        # Quantize to L levels in [-1, 1]
        # Levels: {-1, -1+2/(L-1), ..., 1-2/(L-1), 1}
        levels = np.linspace(-1.0, 1.0, L)
        quantized = np.zeros_like(normalized)

        for i in range(len(normalized)):
            # Find nearest level (stochastic rounding)
            val = normalized[i]
            # Find the two nearest levels
            idx = np.searchsorted(levels, val)
            idx = np.clip(idx, 1, len(levels) - 1)
            lower, upper = levels[idx - 1], levels[idx]

            # Stochastic rounding (unbiased)
            if upper != lower:
                prob_upper = (val - lower) / (upper - lower)
                if np.random.random() < prob_upper:
                    quantized[i] = upper
                else:
                    quantized[i] = lower
            else:
                quantized[i] = lower

        # Scale back
        quantized_values = quantized * C

        # Add discrete Gaussian noise: N_discrete(0, σ²) ≈ continuous Gaussian rounded to integers
        # Then scaled by C/d for per-coordinate DP
        noise_scale = sigma * C / math.sqrt(d)
        continuous_noise = np.random.normal(0, noise_scale, size=d)
        # Discrete Gaussian: round continuous Gaussian to nearest integer step
        step = noise_scale / 3.0  # discretization step
        if step > 0:
            discrete_noise = np.round(continuous_noise / step) * step
        else:
            discrete_noise = continuous_noise

        noisy_gradient = quantized_values + discrete_noise
        return noisy_gradient.astype(np.float32)

    def _local_train(self):
        self.model.train()
        optimizer = torch.optim.SGD(self.model.parameters(), lr=self.eta)
        criterion = nn.CrossEntropyLoss()
        X = torch.tensor(self.X_train, dtype=torch.float32).to(self.device)
        y = torch.tensor(self.X_train.shape[0] * [0], dtype=torch.long).to(self.device)
        # Fix: use y_train, not zeros
        y = torch.tensor(self.y_train, dtype=torch.long).to(self.device)
        dataset = TensorDataset(X, y)
        loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)
        for epoch in range(self.E_local):
            for batch_x, batch_y in loader:
                optimizer.zero_grad()
                outputs = self.model(batch_x)
                loss = criterion(outputs, batch_y)
                loss.backward()
                optimizer.step()

    def evaluate(self, parameters, config):
        self.set_parameters(parameters)
        self.model.eval()
        with torch.no_grad():
            X = torch.tensor(self.X_test, dtype=torch.float32).to(self.device)
            y = torch.tensor(self.y_test, dtype=torch.int64).to(self.device)
            outputs = self.model(X)
            preds = torch.argmax(outputs, dim=1)
            metrics = compute_metrics(y.cpu().numpy(), preds.cpu().numpy())
        return metrics["loss"], len(self.X_test), metrics

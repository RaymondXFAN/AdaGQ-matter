#!/usr/bin/env python3
"""
AdaGQ-Matter 补充实验统计分析脚本。

功能：
1. Wilcoxon signed-rank 检验 (AdaGQ vs DP-FedAvg, AdaGQ vs FedAvg 等)
2. 95% Confidence Interval (5-seed 和 10-seed)
3. 控制器轨迹分析 (b(t), κ(t), σ(t) 随轮次变化)
4. 非饱和 vs 饱和配置对比
5. 输出 Markdown 格式报告，方便直接填入论文

用法:
    python scripts/analysis_supplement.py
    python scripts/analysis_supplement.py --results_dir results
"""

import os
import sys
import json
import glob
import argparse
import numpy as np
from pathlib import Path
from datetime import datetime

# --- Optional imports ---
try:
    from scipy.stats import wilcoxon, mannwhitneyu, ttest_rel
    HAS_SCIPY = True
except ImportError:
    HAS_SCIPY = False
    print("⚠️ scipy 未安装, Wilcoxon检验不可用。安装: pip install scipy")

try:
    from scipy.stats import norm
    HAS_NORM = True
except ImportError:
    HAS_NORM = False


def load_results(results_dir, method, dataset="iotid20", alpha=0.5):
    """Load all seed results for a given method."""
    pattern = os.path.join(results_dir, f"{method}_{dataset}_alpha{alpha}_seed*.json")
    files = sorted(glob.glob(pattern))
    results = {}
    for f in files:
        # Extract seed from filename
        basename = os.path.basename(f)
        seed = int(basename.split("seed")[1].replace(".json", ""))
        with open(f, "r") as fh:
            data = json.load(fh)
        if "final_metrics" in data:
            results[seed] = data["final_metrics"]
    return results


def load_round_results(results_dir, method, dataset="iotid20", alpha=0.5, seed=1):
    """Load per-round results for trajectory analysis."""
    path = os.path.join(results_dir, f"{method}_{dataset}_alpha{alpha}_seed{seed}.json")
    if not os.path.exists(path):
        return None
    with open(path, "r") as f:
        data = json.load(f)
    return data.get("round_results", [])


def mean_std(values):
    """Compute mean ± std."""
    arr = np.array(values, dtype=float)
    return np.nanmean(arr), np.nanstd(arr, ddof=1) if len(arr) > 1 else 0.0


def confidence_interval(values, confidence=0.95):
    """Compute confidence interval using t-distribution."""
    arr = np.array(values, dtype=float)
    n = len(arr)
    if n < 2:
        return arr[0], arr[0], arr[0]
    mean = np.nanmean(arr)
    se = np.nanstd(arr, ddof=1) / np.sqrt(n)
    if HAS_NORM:
        # Use t-distribution for small samples
        from scipy.stats import t as t_dist
        t_val = t_dist.ppf((1 + confidence) / 2, df=n - 1)
    else:
        # Fallback: use 1.96 for 95% CI (normal approximation)
        t_val = 1.96
    lower = mean - t_val * se
    upper = mean + t_val * se
    return mean, lower, upper


def wilcoxon_test(values_a, values_b, alternative="two-sided"):
    """Run Wilcoxon signed-rank test."""
    if not HAS_SCIPY:
        return {"statistic": None, "p_value": None, "significant_005": None}
    if len(values_a) < 5 or len(values_b) < 5:
        return {"statistic": None, "p_value": None, "significant_005": "insufficient_data"}
    try:
        stat, p = wilcoxon(values_a, values_b, alternative=alternative)
        return {
            "statistic": float(stat),
            "p_value": float(p),
            "significant_005": p < 0.05,
        }
    except ValueError as e:
        return {"statistic": None, "p_value": None, "significant_005": f"error: {e}"}


def variance_ratio_ci(values_a, values_b, confidence=0.95):
    """Compute variance ratio and its CI (F-test based)."""
    var_a = np.var(values_a, ddof=1)
    var_b = np.var(values_b, ddof=1)
    if var_b == 0:
        return {"ratio": float("inf"), "ci_lower": None, "ci_upper": None}
    ratio = var_b / var_a  # larger_var / smaller_var
    if HAS_SCIPY:
        from scipy.stats import f as f_dist
        n_a, n_b = len(values_a), len(values_b)
        # F distribution CI for variance ratio
        f_lower = f_dist.ppf((1 - confidence) / 2, n_b - 1, n_a - 1)
        f_upper = f_dist.ppf((1 + confidence) / 2, n_b - 1, n_a - 1)
        ci_lower = ratio / f_upper
        ci_upper = ratio / f_lower
        return {"ratio": float(ratio), "ci_lower": float(ci_lower), "ci_upper": float(ci_upper)}
    return {"ratio": float(ratio), "ci_lower": None, "ci_upper": None}


def analyze_main_results(results_dir):
    """Analyze main experiment results (Table 3 补充)."""
    methods = ["fedavg", "fedprox", "top_k_only", "quant_only",
               "naive_combination", "dp_fedavg", "adagq"]
    metrics_keys = ["f1", "accuracy", "precision", "recall", "auc"]

    report = []
    report.append("## 1. 主实验完整指标 (Table 3 补充)")
    report.append("")
    report.append("| Method | F1 | Accuracy | FPR | AUC | 95% CI (F1) |")
    report.append("|--------|-----|----------|-----|-----|-------------|")

    all_metrics = {}
    for method in methods:
        results = load_results(results_dir, method)
        if not results:
            report.append(f"| {method} | N/A | N/A | N/A | N/A | N/A |")
            continue
        all_metrics[method] = {}
        for mk in metrics_keys:
            vals = [v.get(mk, float("nan")) for v in results.values()]
            vals = [v for v in vals if not np.isnan(v)]
            all_metrics[method][mk] = vals

        f1_vals = all_metrics[method].get("f1", [])
        acc_vals = all_metrics[method].get("accuracy", [])
        auc_vals = all_metrics[method].get("auc", [])

        f1_mean, f1_std = mean_std(f1_vals)
        acc_mean, _ = mean_std(acc_vals)
        fpr_mean = 1.0 - np.mean(all_metrics[method].get("precision", [1.0]))
        auc_mean, _ = mean_std(auc_vals)
        _, ci_lo, ci_hi = confidence_interval(f1_vals)

        report.append(
            f"| {method} | {f1_mean:.4f}±{f1_std:.4f} | {acc_mean:.4f} | "
            f"{fpr_mean:.4f} | {auc_mean:.4f} | [{ci_lo:.4f}, {ci_hi:.4f}] |"
        )

    report.append("")
    return "\n".join(report), all_metrics


def analyze_statistical_tests(all_metrics):
    """Wilcoxon and variance ratio tests."""
    report = []
    report.append("## 2. 统计显著性检验")
    report.append("")

    # AdaGQ vs DP-FedAvg (matched-σ)
    adagq_f1 = all_metrics.get("adagq", {}).get("f1", [])
    dpfedavg_f1 = all_metrics.get("dp_fedavg", {}).get("f1", [])

    if adagq_f1 and dpfedavg_f1:
        min_len = min(len(adagq_f1), len(dpfedavg_f1))
        report.append(f"### 2.1 AdaGQ vs DP-FedAvg (F1, n={min_len})")
        w_result = wilcoxon_test(adagq_f1[:min_len], dpfedavg_f1[:min_len])
        report.append(f"- Wilcoxon statistic: {w_result['statistic']}")
        report.append(f"- p-value: {w_result['p_value']:.4f}" if w_result['p_value'] else "- p-value: N/A")
        report.append(f"- Significant (α=0.05): {w_result['significant_005']}")
        report.append("")

        # Variance ratio
        vr = variance_ratio_ci(np.array(dpfedavg_f1[:min_len]), np.array(adagq_f1[:min_len]))
        report.append(f"### 2.2 Variance Ratio (DP-FedAvg / AdaGQ)")
        report.append(f"- Ratio: {vr['ratio']:.2f}")
        if vr['ci_lower']:
            report.append(f"- 95% CI: [{vr['ci_lower']:.2f}, {vr['ci_upper']:.2f}]")
        report.append("")

    # AdaGQ vs FedAvg
    fedavg_f1 = all_metrics.get("fedavg", {}).get("f1", [])
    if adagq_f1 and fedavg_f1:
        min_len = min(len(adagq_f1), len(fedavg_f1))
        report.append(f"### 2.3 AdaGQ vs FedAvg (F1, n={min_len})")
        w_result = wilcoxon_test(adagq_f1[:min_len], fedavg_f1[:min_len])
        report.append(f"- Wilcoxon p-value: {w_result['p_value']:.4f}" if w_result['p_value'] else "- Wilcoxon: N/A")
        report.append("")

    return "\n".join(report)


def analyze_controller_trajectories(results_dir, config_name="nonsat_eps50_T50"):
    """Analyze controller trajectories for non-saturated experiments."""
    report = []
    report.append("## 3. 控制器轨迹分析 (非饱和 vs 饱和)")
    report.append("")

    # Load AdaGQ round results
    rr_nonsat = load_round_results(results_dir, "adagq")
    rr_sat = load_round_results(results_dir, "adagq")  # from default config

    if rr_nonsat:
        report.append("### 3.1 非饱和配置 (ε=50, T=50)")
        report.append("")
        report.append("| Round | F1 | σ(t) | ε_cumulative | Comm(KB) |")
        report.append("|-------|-----|------|---------------|----------|")
        for rr in rr_nonsat[::5]:  # Every 5 rounds
            report.append(
                f"| {rr['round']} | {rr['f1']:.4f} | "
                f"{rr.get('epsilon', 0):.3f} | {rr.get('comm_bytes', 0)/1024:.1f} |"
            )
        report.append("")

        # Check if σ varies
        sigmas = [rr.get("epsilon", 0) for rr in rr_nonsat]  # Using epsilon as proxy
        sigma_range = max(sigmas) - min(sigmas)
        report.append(f"**σ 变化范围**: {sigma_range:.4f}")
        if sigma_range < 0.01:
            report.append("⚠️ σ 仍然恒定，控制器未激活")
        else:
            report.append("✅ σ 在动态范围内变化，控制器已激活")
        report.append("")

    return "\n".join(report)


def analyze_matched_sigma(results_dir):
    """Analyze matched-σ DP-FedAvg results."""
    report = []
    report.append("## 4. Matched-σ DP-FedAvg 完整指标")
    report.append("")

    # Load matched-σ results
    results = load_results(results_dir, "dp_fedavg")
    if not results:
        report.append("*暂无数据，等待实验完成*")
        return "\n".join(report)

    metrics_keys = ["f1", "accuracy", "precision", "recall", "auc"]
    report.append("| Metric | Mean ± Std | 95% CI |")
    report.append("|--------|-----------|--------|")

    for mk in metrics_keys:
        vals = [v.get(mk, float("nan")) for v in results.values()]
        vals = [v for v in vals if not np.isnan(v)]
        if not vals:
            report.append(f"| {mk} | N/A | N/A |")
            continue
        m, s = mean_std(vals)
        _, ci_lo, ci_hi = confidence_interval(vals)
        report.append(f"| {mk} | {m:.4f}±{s:.4f} | [{ci_lo:.4f}, {ci_hi:.4f}] |")

    report.append("")
    return "\n".join(report)


def analyze_cpsgd(results_dir):
    """Analyze cpSGD baseline results."""
    report = []
    report.append("## 5. cpSGD 基线实测结果")
    report.append("")

    results = load_results(results_dir, "cpsgd")
    if not results:
        report.append("*暂无数据，等待实验完成*")
        return "\n".join(report)

    f1_vals = [v.get("f1", float("nan")) for v in results.values()]
    f1_vals = [v for v in f1_vals if not np.isnan(v)]
    m, s = mean_std(f1_vals)
    report.append(f"- cpSGD F1 (5-seed mean): {m:.4f}±{s:.4f}")
    report.append(f"- Seeds: {len(results)}")
    report.append("")

    return "\n".join(report)


def main():
    parser = argparse.ArgumentParser(description="Supplementary experiment analysis")
    parser.add_argument("--results_dir", default="results", help="Results directory")
    parser.add_argument("--output", default="results/supplement_analysis.md",
                        help="Output report path")
    args = parser.parse_args()

    results_dir = args.results_dir
    output_path = args.output

    report = []
    report.append("# AdaGQ-Matter 补充实验分析报告")
    report.append(f"\n生成时间: {datetime.now().isoformat()}\n")
    report.append("---\n")

    # 1. Main results with full metrics
    print("📊 分析主实验完整指标...")
    main_report, all_metrics = analyze_main_results(results_dir)
    report.append(main_report)

    # 2. Statistical tests
    print("📊 运行统计显著性检验...")
    stat_report = analyze_statistical_tests(all_metrics)
    report.append(stat_report)

    # 3. Controller trajectories
    print("📊 分析控制器轨迹...")
    traj_report = analyze_controller_trajectories(results_dir)
    report.append(traj_report)

    # 4. Matched-σ DP-FedAvg
    print("📊 分析 Matched-σ DP-FedAvg...")
    ms_report = analyze_matched_sigma(results_dir)
    report.append(ms_report)

    # 5. cpSGD baseline
    print("📊 分析 cpSGD 基线...")
    cpsgd_report = analyze_cpsgd(results_dir)
    report.append(cpsgd_report)

    # Save report
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w") as f:
        f.write("\n".join(report))

    print(f"\n✅ 分析报告已保存: {output_path}")
    print("\n" + "=" * 60)
    print(report[:2000] if len("\n".join(report)) > 2000 else "\n".join(report))


if __name__ == "__main__":
    main()
